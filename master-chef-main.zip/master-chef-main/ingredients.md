2 ⅛ cups all-purpose flour
2 cups white sugar
¾ cup unsweetened cocoa powder
1 ½ teaspoons baking powder
¾ teaspoon baking soda
¾ teaspoon salt
3 large eggs eggs
1 cup milk
½ cup vegetable oil
1 tablespoon vanilla extract
2 (20 ounce) cans pitted sour cherries
1 cup white sugar
¼ cup cornstarch
1 teaspoon vanilla extract
3 cups heavy whipping cream
⅓ cup confectioners' sugar
Add All Ingredients To Sho